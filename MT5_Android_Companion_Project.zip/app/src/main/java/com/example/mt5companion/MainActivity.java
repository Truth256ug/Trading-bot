package com.example.mt5companion;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.view.View;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    EditText bridgeUrl, symbol, lot, sl, tp;
    TextView status;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        bridgeUrl=findViewById(R.id.bridgeUrl); symbol=findViewById(R.id.symbol);
        lot=findViewById(R.id.lot); sl=findViewById(R.id.sl); tp=findViewById(R.id.tp);
        status=findViewById(R.id.status);

        findViewById(R.id.connect).setOnClickListener(v -> request("/health", ""));
        findViewById(R.id.buy).setOnClickListener(v -> order("BUY"));
        findViewById(R.id.sell).setOnClickListener(v -> order("SELL"));
        findViewById(R.id.closeAll).setOnClickListener(v -> request("/close-all", ""));
    }

    void order(String side) {
        String json = "{\"symbol\":\""+symbol.getText()+"\",\"side\":\""+side+
                "\",\"lot\":"+lot.getText()+",\"sl_points\":"+sl.getText()+
                ",\"tp_points\":"+tp.getText()+"}";
        request("/order", json);
    }

    void request(String path, String body) {
        String base=bridgeUrl.getText().toString().trim();
        if(base.isEmpty()){ status.setText("Enter your secure MT5 bridge URL."); return; }
        new Thread(() -> {
            try {
                URL u=new URL(base+path);
                HttpURLConnection c=(HttpURLConnection)u.openConnection();
                c.setRequestMethod(body.isEmpty() ? "GET" : "POST");
                c.setConnectTimeout(8000); c.setReadTimeout(8000);
                c.setRequestProperty("Content-Type","application/json");
                if(!body.isEmpty()){
                    c.setDoOutput(true);
                    try(OutputStream os=c.getOutputStream()){
                        os.write(body.getBytes(StandardCharsets.UTF_8));
                    }
                }
                int code=c.getResponseCode();
                runOnUiThread(() -> status.setText("Bridge response: HTTP "+code));
                c.disconnect();
            } catch(Exception e) {
                runOnUiThread(() -> status.setText("Connection error: "+e.getMessage()));
            }
        }).start();
    }
}
