# MT5 Android Companion

This is an Android companion-app project for an MT5 trading bridge.

## Important
The Android MT5 app does not execute `.mq5` Expert Advisors. This companion sends commands to a secure bridge, and the bridge/VPS communicates with MetaTrader 5.

## Current app features
- Bridge URL configuration
- Connection/health check
- BUY and SELL command buttons
- Symbol and lot size
- Stop-loss and take-profit points
- Close-all command
- No MT5 password stored in the app

## Required bridge API
The bridge should expose:
- GET /health
- POST /order with JSON: {"symbol":"EURUSD","side":"BUY","lot":0.01,"sl_points":150,"tp_points":250}
- POST /close-all

The bridge must validate authentication, symbol, lot limits, SL/TP, account permissions and duplicate requests before sending orders to MT5.

## Build
Open this folder in Android Studio and build an APK.

This project is intentionally not connected to a real broker by default. A real connection requires your chosen MT5 bridge/VPS and secure credentials on that bridge.
